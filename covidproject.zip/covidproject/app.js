const express=require("express");
const https=require("https");
const ejs=require("ejs");
const bodyparser=require("body-parser")
var unirest = require("unirest");
const app=express();

app.use(bodyparser.urlencoded({extended:true}));
app.set("view engine","ejs");
app.use(express.static("public"));



app.get("/",function(req,res){

var url="https://api.covid19api.com/world/total";
https.get(url,function(response){
  response.on("data",function(data){
   var dat=JSON.parse(data)
   var tcs=dat.TotalConfirmed;
   var td=dat.TotalDeaths;
   var tc=dat.TotalRecovered;

   var today = new Date();
  var options={
    weekday:"long",
    day:"numeric",
    month:"long"
  }
 var day=today.toLocaleDateString("en-us",options);


   res.render("index",{tcs:tcs,td:td,tc:tc,day:day});
  })
})







});











app.listen(process.env.PORT || 3000,function(){
  console.log("server ready");
})
